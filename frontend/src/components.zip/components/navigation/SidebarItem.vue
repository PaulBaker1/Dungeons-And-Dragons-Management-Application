<template>
  <router-link
      :to="to"
      class="flex items-center space-x-3 py-2 px-4 hover:bg-slate-700 transition"
      active-class="bg-slate-700"
  >
    <i :class="icon" class="text-sm w-5 text-slate-400" />
    <span v-if="!isCollapsed" class="text-sm">{{ label }}</span>
  </router-link>
</template>

<script setup>
import { useSidebarStore } from '@/store/sidebarStore'
defineProps({
  to: String,
  label: String,
  icon: String
})

const sidebar = useSidebarStore()
const isCollapsed = sidebar.isCollapsed
</script>
