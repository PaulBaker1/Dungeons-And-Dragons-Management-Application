<template>
  <div>
    <h3 class="text-slate-300 font-semibold mb-2">{{ title }}</h3>
    <ul class="space-y-1">
      <li v-for="(item, idx) in items" :key="idx">
        <a :href="item.href" class="hover:text-white text-slate-400">{{ item.label }}</a>
      </li>
    </ul>
  </div>
</template>

<script setup>
defineProps({
  title: String,
  items: Array
})
</script>
