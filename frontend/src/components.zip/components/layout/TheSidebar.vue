<template>
  <transition name="slide">
    <div
        id="sidebar"
        :class="{
        'side-collapsed': sidebar.isCollapsed && !sidebar.smallScreen,
        slideIn: false // future: if you want sidebar toggle on route change
      }"
    >
      <div>
        <h3 class="px-3 text-xs text-slate-400 uppercase font-bold mt-4 mb-2">DM Content</h3>
        <nav @click="sidebar.setSideSmallScreen(false)">
          <SidebarItem icon="fas fa-dungeon" label="Campaigns" to="/campaigns" />
          <SidebarItem icon="fas fa-users" label="Players" to="/content/players" />
          <SidebarItem icon="fas fa-dragon" label="NPCs" to="/content/npcs" />
          <SidebarItem icon="fas fa-wand-magic" label="Spells" to="/content/spells" />
          <SidebarItem icon="fas fa-stopwatch" label="Reminders" to="/content/reminders" />
          <SidebarItem icon="fas fa-staff" label="Items" to="/content/items" />
          <SidebarItem icon="fas fa-file-upload" label="Import" to="/content/import" />
        </nav>

        <h3 class="px-3 text-xs text-slate-400 uppercase font-bold mt-6 mb-2">Player Content</h3>
        <nav>
          <SidebarItem icon="fas fa-helmet-battle" label="Characters" to="/content/characters" />
          <SidebarItem
              icon="fas fa-user-check"
              label="Followed Users"
              to="/content/followed"
          />
        </nav>
      </div>
    </div>
  </transition>
</template>

<script setup>
import { useSidebarStore } from '@/store/sidebarStore.js'
import SidebarItem from '../navigation/SidebarItem.vue'

const sidebar = useSidebarStore()
</script>

<style scoped>
#sidebar {
  width: 250px;
  height: 100vh;
  background: #1e293b;
  color: white;
  transition: width 0.3s ease;
  border-right: 1px solid #334155;
  overflow-y: auto;
}

#sidebar.side-collapsed {
  width: 60px;
}

#toggle-width {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 1rem;
  cursor: pointer;
  text-align: right;
  background: #1e293b;
  border-top: 1px solid #334155;
}

.slide-enter-active,
.slide-leave-active {
  transition: all 0.3s ease;
}

.slide-enter-from,
.slide-leave-to {
  transform: translateX(-100%);
}
</style>
