<template>
  <transition name="fade">
    <footer id="footerbar">
      <div class="pt-6 pb-10 px-6">

        <!-- Logo & Description -->
        <div class="mb-8">
          <img src="/logo.svg" alt="Shieldmaiden" class="h-10 mb-2" />
          <p class="text-xs text-slate-500 leading-relaxed">
            ©2025 Shieldmaiden. All rights reserved. Icons by Delapouite, Lorc & Skull.<br />
            Content released under the <a href="#" class="underline hover:text-white">OGL 1.0a</a>.
          </p>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6 text-sm">

          <FooterColumn title="Quick Links" :items="[
            { label: 'Compendium', href: '#' },
            { label: 'Documentation', href: '#' },
            { label: 'Support', href: '#' },
            { label: 'Feedback', href: '#' },
          ]" />

          <FooterColumn title="DM Content" :items="[
            { label: 'Campaigns', href: '#' },
            { label: 'Players', href: '#' },
            { label: 'NPCs', href: '#' },
            { label: 'Items', href: '#' },
          ]" />

          <FooterColumn title="Player Content" :items="[
            { label: 'Characters', href: '#' },
            { label: 'Following', href: '#' },
            { label: 'Account', href: '#' },
          ]" />

          <FooterColumn title="Follow Us" :items="[
            { label: 'Discord', href: '#' },
            { label: 'Patreon', href: '#' },
            { label: 'Twitter', href: '#' },
            { label: 'GitHub', href: '#' },
          ]" />
        </div>
      </div>
    </footer>
  </transition>
</template>

<script setup>
import FooterColumn from '@/components/navigation/FooterColumn.vue'
</script>

<style scoped>
#footerbar {
  background-color: #1e293b;
  color: white;
  border-top: 1px solid #334155;
}

.fade-enter-active,
.fade-leave-active {
  transition: all 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateY(20px);
}
</style>
