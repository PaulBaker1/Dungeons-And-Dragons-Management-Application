<template>
  <div class="px-6 py-6 max-w-4xl mx-auto text-white">
    <h1 class="text-3xl font-bold mb-8">🛠 Create a New Campaign</h1>

    <form @submit.prevent="submitForm" class="space-y-10">

      <!-- Campaign Info -->
      <section class="space-y-6">
        <div>
          <label class="block text-sm font-medium mb-1">Title</label>
          <input v-model="form.title" class="input" placeholder="Enter campaign title" required />
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Description</label>
          <textarea v-model="form.description" class="input" rows="4" placeholder="What's this campaign about?" />
        </div>
      </section>

      <!-- Level Range -->
      <section>
        <label class="block text-sm font-medium mb-2">Recommended Level Range</label>
        <div class="flex flex-col sm:flex-row gap-4">
          <div class="flex-1">
            <label class="block text-xs mb-1">Min Level</label>
            <input type="number" v-model="form.minLevel" class="input" min="1" max="20" />
          </div>
          <div class="flex-1">
            <label class="block text-xs mb-1">Max Level</label>
            <input type="number" v-model="form.maxLevel" class="input" min="1" max="20" />
          </div>
        </div>
      </section>

      <!-- Tags -->
      <section>
        <label class="block text-sm font-medium mb-2">Tags</label>
        <input
            v-model="tagInput"
            @keydown.enter.prevent="addTag"
            class="input"
            placeholder="Press Enter to add tag"
        />
        <div class="flex flex-wrap mt-2 gap-2">
          <span
              v-for="(tag, index) in form.tags"
              :key="index"
              class="bg-indigo-600 text-white text-sm px-3 py-1 rounded-full flex items-center"
          >
            {{ tag }}
            <button @click.prevent="removeTag(index)" class="ml-2 hover:text-red-300">✕</button>
          </span>
        </div>
      </section>

      <!-- Locations -->
      <section>
        <label class="block text-sm font-medium mb-2">Key Locations</label>
        <div v-for="(loc, index) in form.locations" :key="index" class="flex gap-2 mb-2">
          <input v-model="form.locations[index]" class="input flex-1" />
          <button @click.prevent="removeLocation(index)" class="text-red-400 hover:text-red-300">✕</button>
        </div>
        <button @click.prevent="addLocation" class="btn-outline mt-2">+ Add Location</button>
      </section>

      <!-- Sections -->
      <section>
        <label class="block text-sm font-medium mb-2">Sections</label>
        <div v-for="(sec, index) in form.sections" :key="index" class="flex gap-2 mb-2">
          <input v-model="form.sections[index]" class="input flex-1" />
          <button @click.prevent="removeSection(index)" class="text-red-400 hover:text-red-300">✕</button>
        </div>
        <button @click.prevent="addSection" class="btn-outline mt-2">+ Add Section</button>
      </section>

      <!-- Status & Visibility -->
      <section class="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div>
          <label class="block text-sm font-medium mb-1">Status</label>
          <select v-model="form.status" class="input">
            <option value="DRAFT">Draft</option>
            <option value="ACTIVE">Active</option>
            <option value="COMPLETED">Completed</option>
            <option value="ARCHIVED">Archived</option>
          </select>
        </div>
        <div class="flex flex-col justify-center gap-4 mt-2 sm:mt-0">
          <label class="flex items-center gap-2">
            <input type="checkbox" v-model="form.visibleToPlayers" />
            <span class="text-sm">Visible to Players</span>
          </label>
          <label class="flex items-center gap-2">
            <input type="checkbox" v-model="form.pinned" />
            <span class="text-sm">Pinned</span>
          </label>
        </div>
      </section>

      <!-- Submit -->
      <button type="submit" class="btn-primary w-full mt-6">🎉 Create Campaign</button>
    </form>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import axios from 'axios'
import { useRouter } from 'vue-router'

const router = useRouter()
const tagInput = ref('')

const form = reactive({
  title: '',
  description: '',
  minLevel: 1,
  maxLevel: 20,
  tags: [],
  sections: [],
  locations: [],
  status: 'DRAFT',
  visibleToPlayers: false,
  pinned: false
})

function addTag() {
  if (tagInput.value.trim() && !form.tags.includes(tagInput.value.trim())) {
    form.tags.push(tagInput.value.trim())
    tagInput.value = ''
  }
}

function removeTag(index) {
  form.tags.splice(index, 1)
}

function addLocation() {
  form.locations.push('')
}

function removeLocation(index) {
  form.locations.splice(index, 1)
}

function addSection() {
  form.sections.push('')
}

function removeSection(index) {
  form.sections.splice(index, 1)
}

async function submitForm() {
  try {
    const payload = {
      title: form.title,
      description: form.description,
      archived: false,
      recommendedLevelRange: {
        minLevel: form.minLevel,
        maxLevel: form.maxLevel
      },
      status: form.status,
      visibleToPlayers: form.visibleToPlayers,
      pinned: form.pinned,
      sections: form.sections.map(title => ({ title })),
      keyLocations: form.locations.map(name => ({ name })),
      tags: form.tags.map(name => ({ name }))
    }

    await axios.post(`${import.meta.env.VITE_API_BASE_URL}/api/campaigns/create`, payload)
    await store.fetchCampaigns(); // 🔁 Refresh the list
    router.push('/campaigns')
  } catch (err) {
    console.error('Error creating campaign:', err)
    alert('Failed to create campaign.')
  }
}
</script>

<style scoped>
.input {
  @apply w-full px-3 py-2 rounded bg-slate-800 text-white border border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-400;
}
.btn-primary {
  @apply bg-green-600 hover:bg-green-700 text-white py-2 rounded font-semibold text-center transition duration-150;
}
.btn-outline {
  @apply border border-blue-400 text-blue-300 hover:bg-blue-600 hover:text-white px-3 py-1 rounded text-sm;
}
</style>
