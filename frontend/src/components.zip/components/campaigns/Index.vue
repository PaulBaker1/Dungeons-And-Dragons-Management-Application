<template>
  <div class="flex flex-1">
    <!-- Main Campaigns Area -->
    <div class="flex-1 px-6 py-4 space-y-4">
      <!-- Breadcrumb -->
      <div class="text-sm text-slate-400 flex items-center space-x-2">
        <i class="fas fa-angle-right" />
        <span class="text-slate-300">Content</span>
        <i class="fas fa-angle-right" />
        <span class="text-white font-medium">Campaigns</span>
      </div>

      <!-- Stepper -->
      <CampaignStepper />

      <!-- Instructional Banner -->
      <div class="bg-slate-800 border border-slate-700 rounded-md p-4 flex justify-between items-center">
        <div class="text-slate-300 text-sm">
          Create characters for the players in your party.
        </div>
        <button class="bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium px-4 py-1 rounded">
          Start
        </button>
      </div>

      <!-- Toolbar -->
      <div class="flex items-center justify-between">
        <span class="text-slate-400 text-sm">{{ campaigns.length }} total campaigns</span>
        <div class="flex items-center gap-2">
          <button @click="$router.push('/campaigns/create')" class="btn-primary">
            ➕ New Campaign
          </button>
          <button class="btn-outline">🔍 Filter</button>
          <button class="btn-outline">⬇️ Sort</button>
        </div>
      </div>

      <!-- Campaign Cards Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
        <!-- Add Campaign Card First -->
        <AddCampaignCard />
        <!-- Real Campaigns (limited to 11) -->
        <CampaignCard
            v-for="campaign in visibleCampaigns"
            :key="campaign.id"
            :campaign="campaign"
        />
      </div>

      <!-- Empty state -->
      <div v-if="!campaigns.length" class="text-slate-500 text-sm italic mt-4">
        No campaigns available.
      </div>
    </div>

    <!-- Right Sidebar -->
    <div class="hidden xl:block w-80 border-l border-slate-700 p-4 bg-slate-900 space-y-6">
      <SidebarWidgets />
    </div>
  </div>
</template>

<script setup>
import { onMounted, computed } from 'vue'
import { useCampaignStore } from '@/store/campaignStore'
import CampaignStepper from '@/components/campaigns/CampaignStepper.vue'
import CampaignCard from '@/components/campaigns/CampaignCard.vue'
import AddCampaignCard from '@/components/campaigns/AddCampaignCard.vue'
import SidebarWidgets from '@/components/layout/SidebarWidgets.vue'

const store = useCampaignStore()

onMounted(() => {
  store.fetchCampaigns()
})

const campaigns = computed(() => store.campaigns)

const visibleCampaigns = computed(() =>
    Array.isArray(campaigns.value) ? campaigns.value.slice(0, 11) : []
)
</script>

<style scoped>
.btn-primary {
  @apply bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded text-sm;
}
.btn-outline {
  @apply border border-slate-600 text-slate-300 hover:bg-slate-700 py-2 px-4 rounded text-sm;
}
</style>
