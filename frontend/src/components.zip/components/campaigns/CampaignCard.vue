<template>
  <div class="bg-slate-800 border border-slate-700 rounded-md overflow-hidden relative shadow">
    <img
        :src="campaign.image || fallbackImage"
        alt="Campaign Banner"
        class="w-full h-36 object-cover"
    />

    <!-- Top-right icons -->
    <div class="absolute top-2 right-2 flex gap-2 text-white text-sm">
      <i class="fas fa-thumbtack opacity-80 cursor-pointer" title="Pin"></i>
      <i class="fas fa-trash opacity-80 cursor-pointer" title="Delete"></i>
    </div>

    <div class="p-4 space-y-2">
      <div class="text-xs text-slate-400">Experience advancement</div>
      <div class="text-lg font-semibold text-white truncate" :title="campaign.name">
        {{ campaign.name }}
      </div>

      <div class="text-sm text-slate-300">
        👥 {{ campaign.playerCount ?? 0 }} players &nbsp;
        🧠 {{ campaign.encounterCount ?? 0 }} encounters
      </div>


      <button
          class="bg-blue-500 hover:bg-blue-600 text-white w-full rounded py-1 text-sm mt-2"
      >
        Create players
      </button>
    </div>

    <p class="text-xs text-slate-500">
      Created {{ formatDate(campaign.createdAt) }}
    </p>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  campaign: Object
})

const fallbackImage = 'https://images.unsplash.com/photo-1590608897129-79da98d159ab?fit=crop&w=600&q=80'

function formatDate(iso) {
  if (!iso) return 'Unknown date'
  const date = new Date(iso)
  if (isNaN(date)) return 'Invalid date'
  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  }) + ' at ' + date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })
}

</script>
