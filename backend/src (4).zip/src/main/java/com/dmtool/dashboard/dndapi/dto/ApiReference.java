package com.dmtool.dashboard.dndapi.dto;

public record ApiReference(
        String index,
        String name,
        String url
) {}
