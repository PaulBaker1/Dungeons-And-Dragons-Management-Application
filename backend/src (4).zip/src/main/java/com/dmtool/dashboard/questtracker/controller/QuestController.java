package com.dmtool.dashboard.questtracker.controller;

import com.dmtool.dashboard.questtracker.dto.*;
import com.dmtool.dashboard.questtracker.service.QuestService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class QuestController {

    private final QuestService questService;

    // Create quest within a specific campaign
    @PostMapping("/campaigns/{id}/quests")
    @ResponseStatus(HttpStatus.CREATED)
    public QuestDto createQuest(@PathVariable Long id, @RequestBody CreateQuestRequest request) {
        return questService.createQuest(id, request);
    }

    // Get all quests for a campaign
    @GetMapping("/campaigns/{campaignId}/quests")
    public List<QuestDto> getQuestsByCampaign(@PathVariable Long campaignId) {
        return questService.getQuestsByCampaign(campaignId);
    }

    // Get all quests for a session
    @GetMapping("/sessions/{sessionId}/quests")
    public List<QuestDto> getQuestsBySession(@PathVariable Long sessionId) {
        return questService.getQuestsBySession(sessionId);
    }

    // Get a quest by ID
    @GetMapping("/quests/{id}")
    public QuestDto getQuestById(@PathVariable Long id) {
        return questService.getQuestById(id);
    }

    // Full quest update
    @PutMapping("/quests/{id}")
    public QuestDto updateQuest(@PathVariable Long id,
                                @RequestBody CreateQuestRequest request) {
        return questService.updateQuest(id, request);
    }

    // Delete quest
    @DeleteMapping("/quests/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteQuest(@PathVariable Long id) {
        questService.deleteQuest(id);
    }

    // Partial: update quest status
    @PatchMapping("/quests/{id}/status")
    public QuestDto updateQuestStatus(@PathVariable Long id,
                                      @RequestBody UpdateQuestStatusRequest request) {
        return questService.updateQuestStatus(id, request);
    }

    // Partial: update quest visibility
    @PatchMapping("/quests/{id}/visibility")
    public QuestDto updateQuestVisibility(@PathVariable Long id,
                                          @RequestBody UpdateQuestVisibilityRequest request) {
        return questService.updateQuestVisibility(id, request);
    }
}
