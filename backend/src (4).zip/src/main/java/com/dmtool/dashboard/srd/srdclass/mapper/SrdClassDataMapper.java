package com.dmtool.dashboard.srd.srdclass.mapper;


import com.dmtool.dashboard.srd.srdclass.dto.SrdClassDto;
import com.dmtool.dashboard.srd.srdclass.dto.SrdMulticlassDto;
import com.dmtool.dashboard.srd.srdclass.dto.SrdSpellcastingDto;
import org.mapstruct.Mapper;



@Mapper(componentModel = "spring")
public interface SrdClassDataMapper {

 //   ClassData toClassData(SrdClassDto srdClassDto, SrdSpellcastingDto srdSpellcastingDto, SrdMulticlassDto srdMulticlassDto);
}