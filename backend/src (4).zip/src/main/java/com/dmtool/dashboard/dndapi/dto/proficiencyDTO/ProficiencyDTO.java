package com.dmtool.dashboard.dndapi.dto.proficiencyDTO;

public record ProficiencyDTO(
        String name,
        String type
) {
}
