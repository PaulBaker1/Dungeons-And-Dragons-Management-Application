package com.dmtool.dashboard.dndapi.dto.raceDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RaceSummary {
    private String index;
    private String name;
    private String url;
}