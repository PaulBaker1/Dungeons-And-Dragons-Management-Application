package com.dmtool.dashboard.character.dto;

public record PlayerUpdateCharacterLogRequest()
{ }
