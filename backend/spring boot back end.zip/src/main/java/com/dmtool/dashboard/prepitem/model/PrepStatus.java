package com.dmtool.dashboard.prepitem.model;

public enum PrepStatus {
    TODO,
    IN_PROGRESS,
    READY,   // <— Make sure this is present
    USED
}

