package com.dmtool.dashboard.srd.srdmonster.dto;

import java.util.List;

public record SrdMonsterDto(
    String index,
    String name,
    double challenge_rating,
    int hit_points,
    int armor_class,
    int xp,
    List<String> actions,
    List<String> special_abilities
) {}
