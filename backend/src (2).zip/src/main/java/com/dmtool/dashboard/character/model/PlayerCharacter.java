package com.dmtool.dashboard.character.model;

import com.dmtool.dashboard.campaign.model.Campaign;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "character")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlayerCharacter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String playerName;
    private String characterName;
    private String classAndLevel;

    private int experience;
    private int level;
    private boolean levelOverride;

    private int hitPoints;
    private int armorClass;
    private int spellDC;
    private int speed;
    private int initiative;

    private int strength;
    private int dexterity;
    private int constitution;
    private int intelligence;
    private int wisdom;
    private int charisma;

    private boolean passivePerception;
    private boolean passiveInvestigation;
    private boolean passiveInsight;

    private boolean jackOfAllTrades;

    @ElementCollection
    private List<String> damageResistances;

    @ElementCollection
    private List<String> damageVulnerabilities;

    @ElementCollection
    private List<String> damageImmunities;

    @ElementCollection
    private List<String> conditionImmunities;

    @ElementCollection
    private List<String> skillProficiencies;

    private boolean playerControlled;

    @ManyToOne
    private Campaign campaign;

    @Column(columnDefinition = "TEXT")
    private String notes;

    // ✅ Proper timestamp mappings
    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
