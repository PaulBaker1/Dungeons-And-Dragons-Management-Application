package com.dmtool.dashboard.questtracker.controller;

import com.dmtool.dashboard.questtracker.dto.CreateQuestRequest;
import com.dmtool.dashboard.questtracker.dto.QuestDto;
import com.dmtool.dashboard.questtracker.dto.UpdateQuestStatusRequest;
import com.dmtool.dashboard.questtracker.dto.UpdateQuestVisibilityRequest;
import com.dmtool.dashboard.questtracker.service.QuestService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class QuestController {

    private final QuestService questService;

    @PostMapping("/quests")
    @ResponseStatus(HttpStatus.CREATED)
    public QuestDto createQuest(@RequestBody CreateQuestRequest request) {
        return questService.createQuest(request);
    }

    @PatchMapping("/quests/{id}/status")
    public QuestDto updateQuestStatus(@PathVariable Long id,
                                      @RequestBody UpdateQuestStatusRequest request) {
        return questService.updateQuestStatus(id, request);
    }

    @PatchMapping("/quests/{id}/visibility")
    public QuestDto updateQuestVisibility(@PathVariable Long id,
                                          @RequestBody UpdateQuestVisibilityRequest request) {
        return questService.updateQuestVisibility(id, request);
    }

    @GetMapping("/campaigns/{id}/quests")
    public List<QuestDto> getQuestsByCampaign(@PathVariable("id") Long campaignId) {
        return questService.getQuestsByCampaign(campaignId);
    }

    @GetMapping("/sessions/{id}/quests")
    public List<QuestDto> getQuestsBySession(@PathVariable("id") Long sessionId) {
        return questService.getQuestsBySession(sessionId);
    }

    @DeleteMapping("/quests/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteQuest(@PathVariable Long id) {
        questService.deleteQuest(id);
    }
}
