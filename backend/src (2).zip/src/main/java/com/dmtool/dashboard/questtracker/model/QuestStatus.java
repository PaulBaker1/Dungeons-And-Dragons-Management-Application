package com.dmtool.dashboard.questtracker.model;

public enum QuestStatus {
    PLANNED,
    ACTIVE,
    COMPLETED,
    FAILED
}
