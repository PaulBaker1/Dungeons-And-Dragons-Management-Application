package com.dmtool.dashboard.prepitem.dto;

public record UpdatePrepVisibilityRequest(
        boolean visibleToPlayers
) {}
