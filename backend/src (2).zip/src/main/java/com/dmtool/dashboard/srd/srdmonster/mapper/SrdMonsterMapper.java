package com.dmtool.dashboard.srd.srdmonster.mapper;

import com.dmtool.dashboard.encounterbuilder.model.Combatant;
import com.dmtool.dashboard.srd.srdmonster.dto.SrdMonsterDto;

import java.util.ArrayList;

public class SrdMonsterMapper {

    public static Combatant toCombatant(SrdMonsterDto dto, int quantity) {
        String name = dto.name() + (quantity > 1 ? " x" + quantity : "");
        return Combatant.builder()
                .name(name)
                .hp(dto.hit_points())
                .ac(dto.armor_class())          // Map armor class from SRD
                .xp(dto.xp())
                .cr(dto.challenge_rating())
                .initiative(0)                  // Initiative to be set by DM later
                .isTemplate(true)
                .quantity(quantity)             // Number of monsters represented
                .legendary(dto.special_abilities() != null && !dto.special_abilities().isEmpty())
                .actions(dto.actions() != null ? dto.actions() : new ArrayList<>())
                .specialAbilities(dto.special_abilities() != null ? dto.special_abilities() : new ArrayList<>())
                .build();
    }
}

