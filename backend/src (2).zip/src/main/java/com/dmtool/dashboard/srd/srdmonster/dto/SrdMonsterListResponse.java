package com.dmtool.dashboard.srd.srdmonster.dto;

import java.util.List;

public record SrdMonsterListResponse(
        List<SrdMonsterDto> results
) {}
