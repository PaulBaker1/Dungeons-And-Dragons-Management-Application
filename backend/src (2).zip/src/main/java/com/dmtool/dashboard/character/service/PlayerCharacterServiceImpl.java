package com.dmtool.dashboard.character.service;

import com.dmtool.dashboard.campaign.model.Campaign;
import com.dmtool.dashboard.campaign.repository.CampaignRepository;
import com.dmtool.dashboard.character.dto.PlayerCharacterDto;
import com.dmtool.dashboard.character.dto.PlayerCreateCharacterRequest;
import com.dmtool.dashboard.character.mapper.PlayerCharacterMapper;
import com.dmtool.dashboard.character.model.PlayerCharacter;
import com.dmtool.dashboard.character.repository.PlayerCharacterRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class PlayerCharacterServiceImpl implements PlayerCharacterService {

    private final PlayerCharacterRepository repository;
    private final CampaignRepository campaignRepository;
    private final PlayerCharacterMapper mapper;

    @Override
    public PlayerCharacterDto create(PlayerCreateCharacterRequest request) {
        Campaign campaign = campaignRepository.findById(request.campaignId())
                .orElseThrow(() -> new EntityNotFoundException("Campaign not found"));
        PlayerCharacter character = mapper.toEntity(request);
        character.setCampaign(campaign);
        return mapper.toDto(repository.save(character));
    }

    @Override
    public PlayerCharacterDto update(Long id, PlayerCreateCharacterRequest request) {
        PlayerCharacter character = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Character not found"));
        mapper.updateEntity(character, request);
        return mapper.toDto(repository.save(character));
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public PlayerCharacterDto getById(Long id) {
        return repository.findById(id)
                .map(mapper::toDto)
                .orElseThrow(() -> new EntityNotFoundException("Character not found"));
    }

    @Override
    public List<PlayerCharacterDto> findByCampaign(Long campaignId) {
        return repository.findByCampaign_Id(campaignId)
                .stream()
                .map(mapper::toDto)
                .toList();
    }

    @Override
    public List<PlayerCharacterDto> findAll() {
        return repository.findAll()
                .stream()
                .map(mapper::toDto)
                .toList();
    }

    @Override
    public List<PlayerCharacterDto> findUnassigned() {
        return repository.findByCampaignIsNull().stream().map(mapper::toDto).toList();
    }

    @Override
    public void assignToCampaign(Long campaignId, Long characterId) {
        Campaign campaign = campaignRepository.findById(campaignId)
                .orElseThrow(() -> new EntityNotFoundException("Campaign not found"));
        PlayerCharacter character = repository.findById(characterId)
                .orElseThrow(() -> new EntityNotFoundException("Character not found"));
        character.setCampaign(campaign);
        repository.save(character);
    }
}
