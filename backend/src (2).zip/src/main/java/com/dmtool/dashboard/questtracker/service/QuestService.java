package com.dmtool.dashboard.questtracker.service;

import com.dmtool.dashboard.questtracker.dto.CreateQuestRequest;
import com.dmtool.dashboard.questtracker.dto.QuestDto;
import com.dmtool.dashboard.questtracker.dto.UpdateQuestStatusRequest;
import com.dmtool.dashboard.questtracker.dto.UpdateQuestVisibilityRequest;
import java.util.List;

public interface QuestService {
    QuestDto createQuest(CreateQuestRequest request);
    QuestDto updateQuestStatus(Long id, UpdateQuestStatusRequest request);
    QuestDto updateQuestVisibility(Long id, UpdateQuestVisibilityRequest request);
    List<QuestDto> getQuestsByCampaign(Long campaignId);
    List<QuestDto> getQuestsBySession(Long sessionId);
    void deleteQuest(Long id);
}
