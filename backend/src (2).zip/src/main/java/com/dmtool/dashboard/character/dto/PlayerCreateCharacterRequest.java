package com.dmtool.dashboard.character.dto;

import lombok.Builder;

import java.util.List;

@Builder
public record PlayerCreateCharacterRequest(
        String playerName,
        String characterName,
        String classAndLevel,
        int experience,
        int level,
        boolean levelOverride,
        int hitPoints,
        int armorClass,
        int spellDC,
        int speed,
        int initiative,
        int strength,
        int dexterity,
        int constitution,
        int intelligence,
        int wisdom,
        int charisma,
        boolean passivePerception,
        boolean passiveInvestigation,
        boolean passiveInsight,
        boolean jackOfAllTrades,
        boolean playerControlled,
        List<String> damageResistances,
        List<String> damageVulnerabilities,
        List<String> damageImmunities,
        List<String> conditionImmunities,
        List<String> skillProficiencies,
        Long campaignId,
        String notes
) { }
