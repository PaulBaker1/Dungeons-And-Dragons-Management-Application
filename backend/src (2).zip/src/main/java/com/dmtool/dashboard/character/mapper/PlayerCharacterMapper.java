package com.dmtool.dashboard.character.mapper;

import com.dmtool.dashboard.character.dto.PlayerCharacterDto;
import com.dmtool.dashboard.character.dto.PlayerCreateCharacterRequest;
import com.dmtool.dashboard.character.model.PlayerCharacter;
import org.mapstruct.*;

@Mapper(componentModel = "spring")
public interface PlayerCharacterMapper {
    PlayerCharacterDto toDto(PlayerCharacter playerCharacter);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "campaign", ignore = true)
    PlayerCharacter toEntity(PlayerCreateCharacterRequest request);

    void updateEntity(@MappingTarget PlayerCharacter pc, PlayerCreateCharacterRequest request);
}
