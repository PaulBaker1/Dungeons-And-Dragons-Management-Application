package com.dmtool.dashboard.character.model;

public enum Faction {
    FRIENDLY,
    NEUTRAL,
    HOSTILE
}
