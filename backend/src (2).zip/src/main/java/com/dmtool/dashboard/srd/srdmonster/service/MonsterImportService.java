package com.dmtool.dashboard.srd.srdmonster.service;

import com.dmtool.dashboard.encounterbuilder.dto.EncounterDto;
import com.dmtool.dashboard.encounterbuilder.mapper.EncounterMapper;
import com.dmtool.dashboard.encounterbuilder.model.Combatant;
import com.dmtool.dashboard.encounterbuilder.model.Encounter;
import com.dmtool.dashboard.encounterbuilder.repository.EncounterRepository;
import com.dmtool.dashboard.srd.srdmonster.client.SrdMonsterClient;
import com.dmtool.dashboard.srd.srdmonster.dto.SrdMonsterDto;
import com.dmtool.dashboard.srd.srdmonster.mapper.SrdMonsterMapper;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class MonsterImportService {
    private final EncounterRepository encounterRepository;
    private final SrdMonsterClient srdMonsterClient;
    private final EncounterMapper mapper;

    public EncounterDto importMonsterFromSrd(Long encounterId, String index, int quantity) {
        Encounter encounter = encounterRepository.findById(encounterId)
                .orElseThrow(() -> new EntityNotFoundException("Encounter not found"));

        SrdMonsterDto srdDto = srdMonsterClient.getByIndex(index)
                .orElseThrow(() -> new EntityNotFoundException("Monster not found in SRD"));

        Combatant combatant = SrdMonsterMapper.toCombatant(srdDto, quantity);
        encounter.getCombatants().add(combatant);
        encounterRepository.save(encounter);

        return mapper.toDto(encounter);
    }
}
