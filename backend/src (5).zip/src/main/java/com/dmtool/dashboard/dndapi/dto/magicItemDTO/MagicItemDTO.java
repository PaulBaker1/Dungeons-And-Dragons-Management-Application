package com.dmtool.dashboard.dndapi.dto.magicItemDTO;

public record MagicItemDTO(
        String name,
        String equipment_category
) {
}
