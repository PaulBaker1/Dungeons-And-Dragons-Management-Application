package com.dmtool.dashboard.srd.srdclass.dto;

public record SrdMulticlassDto(
        String prerequisites,
        String proficiencies,
        String multiclassing_bonus
) {}
