package com.dmtool.dashboard.questtracker.model;

public enum QuestPriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
