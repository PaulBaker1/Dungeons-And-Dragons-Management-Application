package com.dmtool.dashboard.dndapi.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public record StartingEquipment(
        EquipmentItem equipment,
        int quantity,
        @JsonProperty("class")
        ApiReference dndClass
) {}
