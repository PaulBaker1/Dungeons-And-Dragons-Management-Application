package com.dmtool.dashboard.questtracker.dto;

import com.dmtool.dashboard.questtracker.model.QuestPriority;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.Set;

public record CreateQuestRequest(
        @NotBlank String title,
        String description,
        Set<String> tags,
        @NotNull QuestPriority priority,
        boolean visibleToPlayers,
        Long linkedSessionId  // optional
) {}
