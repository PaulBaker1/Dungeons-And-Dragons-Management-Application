package com.dmtool.dashboard.dndapi.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class EquipmentDTO {
    // Getters & Setters
    private String index;
    private String name;
    private String equipment_category;
    private Cost cost;
    private int weight;
    private List<EquipmentDTO> contents; // for containers like packs
    private String url;

    public static class Cost {
        private int quantity;
        private String unit;

        // Getters & Setters
        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }

        public String getUnit() { return unit; }
        public void setUnit(String unit) { this.unit = unit; }
    }

}
