package com.dmtool.dashboard.dndapi.service;


import com.dmtool.dashboard.dndapi.dto.*;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

// Inside DnD5eApiService.java

public interface DnD5eApiService {
    Mono<SpellDTO> getSpell(String index);
    Mono<MonsterDTO> getMonster(String index);
    Mono<BackgroundDTO> getBackground(String index);
    Mono<RaceDTO> getRace(String index);
    Mono<ClassDTO> getClassByIndex(String index);
    Mono<EquipmentDTO> getEquipment(String index);
    Mono<LanguageDTO> getLanguage(String index);
    Mono<ProficiencyDTO> getProficiency(String index);
    Mono<MagicItemDTO> getMagicItem(String index);
    Mono<Map> getAll(String type);
    Mono<Map<String, Object>> getAllSrdData();
}

