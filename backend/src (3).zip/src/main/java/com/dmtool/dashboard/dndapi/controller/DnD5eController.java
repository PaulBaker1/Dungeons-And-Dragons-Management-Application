package com.dmtool.dashboard.dndapi.controller;

import com.dmtool.dashboard.dndapi.dto.*;
import com.dmtool.dashboard.dndapi.service.DnD5eApiService;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/api/dnd")
public class DnD5eController {

    private final DnD5eApiService dndService;

    public DnD5eController(DnD5eApiService dndService) {
        this.dndService = dndService;
    }

    @GetMapping("/spells/{index}")
    public Mono<SpellDTO> getSpell(@PathVariable String index) {
        return dndService.getSpell(index);
    }

    @GetMapping("/monsters/{index}")
    public Mono<MonsterDTO> getMonster(@PathVariable String index) {
        return dndService.getMonster(index);
    }

    @GetMapping("/backgrounds/{index}")
    public Mono<BackgroundDTO> getBackground(@PathVariable String index) {
        return dndService.getBackground(index);
    }

    @GetMapping("/races/{index}")
    public Mono<RaceDTO> getRace(@PathVariable String index) {
        return dndService.getRace(index);
    }

    @GetMapping("/classes/{index}")
    public Mono<ClassDTO> getClass(@PathVariable String index) {
        return dndService.getClassByIndex(index);
    }

    @GetMapping("/equipment/{index}")
    public Mono<EquipmentDTO> getEquipment(@PathVariable String index) {
        return dndService.getEquipment(index);
    }

    @GetMapping("/languages/{index}")
    public Mono<LanguageDTO> getLanguage(@PathVariable String index) {
        return dndService.getLanguage(index);
    }

    @GetMapping("/proficiencies/{index}")
    public Mono<ProficiencyDTO> getProficiency(@PathVariable String index) {
        return dndService.getProficiency(index);
    }

    @GetMapping("/magic-items/{index}")
    public Mono<MagicItemDTO> getMagicItem(@PathVariable String index) {
        return dndService.getMagicItem(index);
    }

    @GetMapping("/list/{type}")
    public Mono<Map> getList(@PathVariable String type) {
        return dndService.getAll(type);
    }

    @GetMapping("/fetch-all")
    public Mono<Map<String, Object>> getAllSrdData() {
        return dndService.getAllSrdData();
    }
}
