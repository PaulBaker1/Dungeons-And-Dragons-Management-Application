package com.dmtool.dashboard.dndapi.dto;

public record MonsterDTO(
        String name,
        String size,
        String type,
        int hit_points
) {
}
