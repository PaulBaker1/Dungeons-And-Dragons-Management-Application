package com.dmtool.dashboard.dndapi.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class RaceDTO {
    // Getters & Setters
    private String index;
    private String name;
    private int speed;
    private List<AbilityBonus> ability_bonuses;
    private List<Proficiency> starting_proficiencies;
    private List<Trait> traits;
    private List<Subrace> subraces;
    private String url;

    @Setter
    @Getter
    public static class AbilityBonus {
        private AbilityScore ability_score;
        private int bonus;

    }

    @Setter
    @Getter
    public static class AbilityScore {
        private String index;
        private String name;
        private String url;

    }

    @Setter
    @Getter
    public static class Proficiency {
        private String index;
        private String name;
        private String url;

    }

    @Setter
    @Getter
    public static class Trait {
        private String index;
        private String name;
        private String url;

    }

    @Setter
    @Getter
    public static class Subrace {
        private String index;
        private String name;
        private String url;

    }
}
