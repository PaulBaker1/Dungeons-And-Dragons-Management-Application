package com.dmtool.dashboard.dndapi.dto;

import java.util.List;

public record SpellDTO(
        String name,
        List<String> desc,
        List<String> higher_level,
        String range,
        List<String> components,
        String material,
        String duration,
        String casting_time,
        int level
) {}

