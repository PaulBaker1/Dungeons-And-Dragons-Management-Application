package com.dmtool.dashboard.srd.srdmetadata.dto;

public record SrdFeatureDto(
        String index,
        String name,
        String url,
        String updated_at
) {
}
