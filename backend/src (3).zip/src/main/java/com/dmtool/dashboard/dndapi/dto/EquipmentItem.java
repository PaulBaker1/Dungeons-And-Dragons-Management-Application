package com.dmtool.dashboard.dndapi.dto;

public record EquipmentItem(
        ApiReference equipment,
        int quantity
) {}
