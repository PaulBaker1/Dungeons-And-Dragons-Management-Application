package com.dmtool.dashboard.srd.srdmetadata.dto;

public record ApiReference(
        String index,
        String name,
        String url
) {
}
