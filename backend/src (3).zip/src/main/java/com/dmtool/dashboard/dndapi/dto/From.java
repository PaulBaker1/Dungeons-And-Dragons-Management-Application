package com.dmtool.dashboard.dndapi.dto;

import java.util.List;

public record From(
        List<ApiReference> options
) {}
