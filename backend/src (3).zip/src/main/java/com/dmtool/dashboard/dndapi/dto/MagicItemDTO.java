package com.dmtool.dashboard.dndapi.dto;

public record MagicItemDTO(
        String name,
        String equipment_category
) {
}
