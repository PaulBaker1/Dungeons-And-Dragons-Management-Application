package com.dmtool.dashboard.dndapi.dto;

public record ProficiencyChoice(
        int choose,
        String type,
        From from
) {}
