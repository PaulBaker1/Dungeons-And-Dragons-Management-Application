package com.dmtool.dashboard.dndapi.dto;

public record ProficiencyDTO(
        String name,
        String type
) {
}
