package com.dmtool.dashboard.dndapi.service;

import com.dmtool.dashboard.dndapi.dto.BackgroundDTO;
import com.dmtool.dashboard.dndapi.service.DnD5eApiService.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import com.dmtool.dashboard.dndapi.dto.*;



import java.util.HashMap;
import java.util.Map;

@Service
public class DnD5eApiServiceImpl implements DnD5eApiService {

    private final WebClient webClient;

    public DnD5eApiServiceImpl(@Value("${dnd.api.baseurl:https://www.dnd5eapi.co/api/2014}") String baseUrl) {
        this.webClient = WebClient.builder()
                .baseUrl(baseUrl)
                .build();
    }

    @Override
    public Mono<SpellDTO> getSpell(String index) {
        return webClient.get()
                .uri("/spells/{index}", index)
                .retrieve()
                .bodyToMono(SpellDTO.class)
                .onErrorResume(e -> Mono.error(new RuntimeException("API error: " + e.getMessage(), e)));
    }

    @Override
    public Mono<MonsterDTO> getMonster(String index) {
        return webClient.get()
                .uri("/monsters/{index}", index)
                .retrieve()
                .bodyToMono(MonsterDTO.class);
    }

    @Override
    public Mono<com.dmtool.dashboard.dndapi.dto.BackgroundDTO> getBackground(String index) {
        return webClient.get()
                .uri("/backgrounds/{index}", index)
                .retrieve()
                .bodyToMono(BackgroundDTO.class);
    }

    @Override
    public Mono<RaceDTO> getRace(String index) {
        return webClient.get()
                .uri("/races/{index}", index)
                .retrieve()
                .bodyToMono(RaceDTO.class);
    }

    @Override
    public Mono<ClassDTO> getClassByIndex(String index) {
        return webClient.get()
                .uri("/classes/{index}", index)
                .retrieve()
                .bodyToMono(ClassDTO.class);
    }

    @Override
    public Mono<EquipmentDTO> getEquipment(String index) {
        return webClient.get()
                .uri("/equipment/{index}", index)
                .retrieve()
                .bodyToMono(EquipmentDTO.class);
    }

    @Override
    public Mono<LanguageDTO> getLanguage(String index) {
        return webClient.get()
                .uri("/languages/{index}", index)
                .retrieve()
                .bodyToMono(LanguageDTO.class);
    }

    @Override
    public Mono<ProficiencyDTO> getProficiency(String index) {
        return webClient.get()
                .uri("/proficiencies/{index}", index)
                .retrieve()
                .bodyToMono(ProficiencyDTO.class);
    }

    @Override
    public Mono<MagicItemDTO> getMagicItem(String index) {
        return webClient.get()
                .uri("/magic-items/{index}", index)
                .retrieve()
                .bodyToMono(MagicItemDTO.class);
    }

    @Override
    public Mono<Map> getAll(String type) {
        return webClient.get()
                .uri("/{type}", type)
                .retrieve()
                .bodyToMono(Map.class);
    }

    @Override
    public Mono<Map<String, Object>> getAllSrdData() {
        Mono<Map> spells = getAll("spells");
        Mono<Map> monsters = getAll("monsters");
        Mono<Map> backgrounds = getAll("backgrounds");
        Mono<Map> races = getAll("races");
        Mono<Map> classes = getAll("classes");
        Mono<Map> equipment = getAll("equipment");
        Mono<Map> languages = getAll("languages");
        Mono<Map> proficiencies = getAll("proficiencies");
        Mono<Map> magicItems = getAll("magic-items");

        return Mono.zip(
                objects -> {
                    Map<String, Object> result = new HashMap<>();
                    result.put("spells", objects[0]);
                    result.put("monsters", objects[1]);
                    result.put("backgrounds", objects[2]);
                    result.put("races", objects[3]);
                    result.put("classes", objects[4]);
                    result.put("equipment", objects[5]);
                    result.put("languages", objects[6]);
                    result.put("proficiencies", objects[7]);
                    result.put("magicItems", objects[8]);
                    return result;
                },
                spells, monsters, backgrounds, races, classes, equipment, languages, proficiencies, magicItems
        );
    }
}
