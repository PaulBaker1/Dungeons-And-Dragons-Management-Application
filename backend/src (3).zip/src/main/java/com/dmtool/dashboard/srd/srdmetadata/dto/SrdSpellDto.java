package com.dmtool.dashboard.srd.srdmetadata.dto;

public record SrdSpellDto(
        String index,
        String name,
        String url,
        String updated_at
) {
}
