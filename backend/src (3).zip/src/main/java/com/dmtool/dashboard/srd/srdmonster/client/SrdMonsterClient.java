package com.dmtool.dashboard.srd.srdmonster.client;

import com.dmtool.dashboard.srd.srdmonster.dto.SrdMonsterDto;

import java.util.List;
import java.util.Optional;

public interface SrdMonsterClient {
    List<SrdMonsterDto> search(String name);
    Optional<SrdMonsterDto> getByIndex(String index);
}
