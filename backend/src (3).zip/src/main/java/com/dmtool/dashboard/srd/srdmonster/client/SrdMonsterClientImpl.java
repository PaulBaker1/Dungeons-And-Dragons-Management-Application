package com.dmtool.dashboard.srd.srdmonster.client;

import com.dmtool.dashboard.srd.srdmonster.dto.SrdMonsterDto;
import com.dmtool.dashboard.srd.srdmonster.dto.SrdMonsterListResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class SrdMonsterClientImpl implements SrdMonsterClient {

    private final WebClient webClient;

    @Override
    public List<SrdMonsterDto> search(String name) {
        SrdMonsterListResponse response = webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/monsters")
                        .queryParam("name", name)
                        .build())
                .retrieve()
                .bodyToMono(SrdMonsterListResponse.class)
                .block();
        return response != null ? response.results() : List.of();
    }

    @Override
    public Optional<SrdMonsterDto> getByIndex(String index) {
        SrdMonsterDto dto = webClient.get()
                .uri("/monsters/" + index)
                .retrieve()
                .bodyToMono(SrdMonsterDto.class)
                .block();
        return Optional.ofNullable(dto);
    }
}
