package com.dmtool.dashboard.dndapi.dto;

import java.util.List;

public record LanguageDTO(
        String name,
        String type,
        List<String> typical_speakers
) {
}
