package com.dmtool.dashboard.character.repository;

import com.dmtool.dashboard.character.model.PlayerCharacter;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PlayerCharacterRepository extends JpaRepository<PlayerCharacter, Long> {
    List<PlayerCharacter> findByCampaign_Id(Long campaignId);
    List<PlayerCharacter> findByCampaignIsNull();
}
