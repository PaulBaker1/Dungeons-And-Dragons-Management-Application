package com.dmtool.dashboard.character.controller;

import com.dmtool.dashboard.character.dto.PlayerCreateCharacterRequest;
import com.dmtool.dashboard.character.dto.PlayerCharacterDto;
import com.dmtool.dashboard.character.service.PlayerCharacterService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/characters")
@RequiredArgsConstructor
public class PlayerCharacterController {

    private final PlayerCharacterService service;

    @PostMapping
    public PlayerCharacterDto create(@RequestBody PlayerCreateCharacterRequest request) {
        return service.create(request);
    }

    @GetMapping("/campaign/{campaignId}")
    public List<PlayerCharacterDto> getByCampaign(@PathVariable Long campaignId) {
        return service.findByCampaign(campaignId);
    }

    @PutMapping("/{id}")
    public PlayerCharacterDto update(@PathVariable Long id, @RequestBody PlayerCreateCharacterRequest request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    @GetMapping("/{id}")
    public PlayerCharacterDto getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @GetMapping("")
    public List<PlayerCharacterDto> getAll() {
        return service.findAll();
    }

    @GetMapping("/unassigned")
    public List<PlayerCharacterDto> getUnassignedCharacters() {
        return service.findUnassigned();
    }

    @PostMapping("/campaigns/{campaignId}/characters/{characterId}")
    public void assignCharacterToCampaign(@PathVariable Long campaignId, @PathVariable Long characterId) {
        service.assignToCampaign(campaignId, characterId);
    }
}