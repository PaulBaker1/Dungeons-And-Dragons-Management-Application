package com.dmtool.dashboard.questtracker.service;

import com.dmtool.dashboard.campaign.model.Campaign;
import com.dmtool.dashboard.campaign.repository.CampaignRepository;
import com.dmtool.dashboard.questtracker.dto.CreateQuestRequest;
import com.dmtool.dashboard.questtracker.dto.QuestDto;
import com.dmtool.dashboard.questtracker.dto.UpdateQuestStatusRequest;
import com.dmtool.dashboard.questtracker.dto.UpdateQuestVisibilityRequest;
import com.dmtool.dashboard.questtracker.mapper.QuestMapper;
import com.dmtool.dashboard.questtracker.model.Quest;
import com.dmtool.dashboard.questtracker.model.QuestStatus;
import com.dmtool.dashboard.questtracker.repository.QuestRepository;
import com.dmtool.dashboard.session.model.Session;
import com.dmtool.dashboard.session.repository.SessionRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class QuestServiceImpl implements QuestService {

    private final QuestRepository questRepository;
    private final CampaignRepository campaignRepository;
    private final SessionRepository sessionRepository;
    private final QuestMapper mapper;

    @Override
    public QuestDto createQuest(CreateQuestRequest request) {
        // Load required campaign
        Campaign campaign = campaignRepository.findById(request.campaignId())
                .orElseThrow(() -> new EntityNotFoundException("Campaign not found with id: " + request.campaignId()));

        // Optionally load linked session
        Session linkedSession = null;
        if (request.linkedSessionId() != null) {
            linkedSession = sessionRepository.findById(request.linkedSessionId())
                    .orElseThrow(() -> new EntityNotFoundException("Session not found with id: " + request.linkedSessionId()));
        }

        Quest quest = mapper.toEntity(request);
        quest.setCampaign(campaign);
        quest.setLinkedSession(linkedSession);
        // Set default status to PLANNED
        quest.setStatus(QuestStatus.PLANNED);
        Quest saved = questRepository.save(quest);
        return mapper.toDto(saved);
    }

    @Override
    public QuestDto updateQuestStatus(Long id, UpdateQuestStatusRequest request) {
        Quest quest = questRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Quest not found with id: " + id));
        mapper.updateStatus(request, quest);
        // Optionally, if status is COMPLETED or FAILED, set completedAt timestamp
        if (request.status() == QuestStatus.COMPLETED || request.status() == QuestStatus.FAILED) {
            quest.setCompletedAt(LocalDateTime.now());
        }
        Quest saved = questRepository.save(quest);
        return mapper.toDto(saved);
    }

    @Override
    public QuestDto updateQuestVisibility(Long id, UpdateQuestVisibilityRequest request) {
        Quest quest = questRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Quest not found with id: " + id));
        quest.setVisibleToPlayers(request.visibleToPlayers());
        Quest saved = questRepository.save(quest);
        return mapper.toDto(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<QuestDto> getQuestsByCampaign(Long campaignId) {
        return questRepository.findByCampaign_Id(campaignId)
                .stream()
                .map(mapper::toDto)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<QuestDto> getQuestsBySession(Long sessionId) {
        return questRepository.findByLinkedSession_Id(sessionId)
                .stream()
                .map(mapper::toDto)
                .toList();
    }

    @Override
    public void deleteQuest(Long id) {
        if (!questRepository.existsById(id)) {
            throw new EntityNotFoundException("Quest not found with id: " + id);
        }
        questRepository.deleteById(id);
    }
}
