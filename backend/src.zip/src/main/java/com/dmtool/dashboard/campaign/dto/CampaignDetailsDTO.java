package com.dmtool.dashboard.campaign.dto;

import com.dmtool.dashboard.campaign.model.CampaignStatus;
import com.dmtool.dashboard.campaign.model.LevelRange;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

@Schema(description = "Full details of a campaign")
public record CampaignDetailsDTO(
        @Schema(description = "ID of the campaign", example = "101")
        Long id,

        @Schema(description = "Title of the campaign", example = "Rime of the Frostmaiden")
        String title,

        @Schema(description = "Detailed description", example = "Frozen terror grips the land of Icewind Dale.")
        String description,

        @Schema(description = "Whether this campaign is archived", example = "false")
        boolean archived,

        @Schema(description = "Timestamp of last session", example = "2025-03-23T18:00:00")
        LocalDateTime lastSessionDate,

        @Schema(description = "Whether this campaign is pinned", example = "true")
        boolean pinned,

        @Schema(description = "Private notes (DM only)")
        String dmNotesPrivate,

        @Schema(description = "Public notes (player-visible)")
        String dmNotesPublic,


        LevelRange recommendedLevelRange,
        Set<String> sections,
        Set<String> keyLocations,
        String adventureCode,
        Set<String> involvedFactions,
        Set<String> tags,
        CampaignStatus status,
        Boolean visibleToPlayers
) {
}
