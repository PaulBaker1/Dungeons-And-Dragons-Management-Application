package com.dmtool.dashboard.character.service;

import com.dmtool.dashboard.character.dto.PlayerCharacterDto;
import com.dmtool.dashboard.character.dto.PlayerCreateCharacterRequest;

import java.util.List;

public interface PlayerCharacterService {
    PlayerCharacterDto create(PlayerCreateCharacterRequest request);
    List<PlayerCharacterDto> findByCampaign(Long campaignId);
    PlayerCharacterDto update(Long id, PlayerCreateCharacterRequest request);
    void delete(Long id);
    PlayerCharacterDto getById(Long id); // Optional, for pre-filling edit forms
    List<PlayerCharacterDto> findAll();
    List<PlayerCharacterDto> findUnassigned();
    void assignToCampaign(Long campaignId, Long characterId);
}
