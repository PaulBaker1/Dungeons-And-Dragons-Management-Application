package com.dmtool.dashboard.character.mapper;

import com.dmtool.dashboard.character.dto.PlayerCharacterDto;
import com.dmtool.dashboard.character.dto.PlayerCreateCharacterRequest;
import com.dmtool.dashboard.character.model.PlayerCharacter;
import org.mapstruct.*;

@Mapper(componentModel = "spring")
public interface PlayerCharacterMapper {
    PlayerCharacterDto toDto(PlayerCharacter playerCharacter);
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "campaign", ignore = true)
    PlayerCharacter toEntity(PlayerCreateCharacterRequest request);

    public default void updateEntity(PlayerCharacter character, PlayerCreateCharacterRequest request) {
        character.setPlayerName(request.playerName());
        character.setCharacterName(request.characterName());
        character.setClassAndLevel(request.classAndLevel());
        character.setExperience(request.experience());
        character.setLevel(request.level());
        character.setLevelOverride(request.levelOverride());
        character.setHitPoints(request.hitPoints());
        character.setArmorClass(request.armorClass());
        character.setSpellDC(request.spellDC());
        character.setSpeed(request.speed());
        character.setInitiative(request.initiative());
        character.setStrength(request.strength());
        character.setDexterity(request.dexterity());
        character.setConstitution(request.constitution());
        character.setIntelligence(request.intelligence());
        character.setWisdom(request.wisdom());
        character.setCharisma(request.charisma());
        character.setPassivePerception(request.passivePerception());
        character.setPassiveInvestigation(request.passiveInvestigation());
        character.setPassiveInsight(request.passiveInsight());
        character.setJackOfAllTrades(request.jackOfAllTrades());
        character.setPlayerControlled(request.playerControlled());
        character.setDamageResistances(request.damageResistances());
        character.setDamageVulnerabilities(request.damageVulnerabilities());
        character.setDamageImmunities(request.damageImmunities());
        character.setConditionImmunities(request.conditionImmunities());
        character.setSkillProficiencies(request.skillProficiencies());
        character.setNotes(request.notes());
    }
}
