package com.dmtool.dashboard.campaign.model;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Status of a campaign")
public enum CampaignStatus {
    @Schema(description = "Draft, not yet active")
    DRAFT,

    @Schema(description = "Campaign is live")
    ACTIVE,

    @Schema(description = "Campaign completed")
    COMPLETED,

    @Schema(description = "Archived, no longer visible")
    ARCHIVED
}
